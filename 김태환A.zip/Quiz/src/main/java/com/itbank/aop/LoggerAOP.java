package com.itbank.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;



@Component
@Aspect
public class LoggerAOP {	
	
	private static Logger log = LoggerFactory.getLogger(LoggerAOP.class);
	
	@Around("execution(* com.itbank.service.*.*(..))")
	public Object useTime(ProceedingJoinPoint jp) throws Throwable {
		long begin = System.currentTimeMillis();
				
		Object result = jp.proceed(jp.getArgs());
		
		long end = System.currentTimeMillis();
		
		String msg = jp.getSignature().getName();
		
		msg += "소요시간 : " + (end - begin) / 1000.0 + "초";
        
        log.debug(msg);
		
		return result;
	}
	
	
	
	
	
}
