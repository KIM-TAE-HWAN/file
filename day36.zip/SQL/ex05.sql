delete from person where name = '김수진';
update person set name = '박수철' where name = '박철수';

select * from person_back;
commit;