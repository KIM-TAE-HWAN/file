package com.itbank.Controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;



import com.itbank.model.vo.AccountVO;
import com.itbank.service.AccountService;

@Controller
@RequestMapping("/account")
public class AccountController {
	
	@Autowired
	private AccountService as;
	
	@GetMapping("/login")
	public void login() {}
	
	@PostMapping("/login")
	public String login(AccountVO input, HttpSession session) {
		
		input = as.login(input);
		
		if (input != null) {
			session.setAttribute("user", input);
		}
		
		return "redirect:/";
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.removeAttribute("user");
		
		return "redirect:/";
	}
	
	@GetMapping("/signUp")
	public void signUp() {}
	
	@PostMapping("/signUp")
	public String singUp(AccountVO input) {
		as.addAcc(input);
		
		return "redirect:/";
	}
	
	@GetMapping("/myPage")
	public void myPage() {}
	
	@GetMapping("/update")
	public void update() {}
	
	@PostMapping("/update")
	public String update(AccountVO input, HttpSession session) {
		AccountVO user = (AccountVO) session.getAttribute("user");
				
		int idx = user.getIdx();
		input.setIdx(idx);
				
		as.update(input);
		
		return "redirect:/account/logout";
	}
	
	@GetMapping("/delete/{idx}")
	public String delete(@PathVariable int idx) {
		as.delAcc(idx);
		
		return "redirect:/account/logout";
	}
	
	
	
}
