package com.itbank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.itbank.components.SHA512;
import com.itbank.model.AccountDAO;
import com.itbank.model.vo.AccountVO;


@Service
public class AccountService {
	
	@Autowired
	private SHA512 hash;
	
	@Autowired
	private AccountDAO dao;
	
	public List<AccountVO> getAcc() {
		return dao.selectAll();
	}

	public AccountVO login(AccountVO input) {
		String pw = input.getUserpw();
		input.setUserpw(hash.getHash(pw));
		
		return dao.selectOne(input);
	}
	
	@Transactional(rollbackFor = Exception.class)
	public int addAcc(AccountVO input) {
		String pw = input.getUserpw();
		input.setUserpw(hash.getHash(pw));
		
		
		return dao.insert(input);
	}

	public int update(AccountVO input) {
		String pw = input.getUserpw();
		input.setUserpw(hash.getHash(pw));
		
			return dao.update(input);
		}

	public int delAcc(int idx) {
		return dao.delete(idx);
		
	}


}
