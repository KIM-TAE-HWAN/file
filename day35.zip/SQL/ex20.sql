-- 3. 저장된 프로시저 사용
begin
    test1();
end;

execute test1();

exec test1();